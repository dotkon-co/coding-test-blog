import { Component, OnDestroy, OnInit } from '@angular/core';
import { SignalrService } from './services/signalr.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  constructor(private signalRService: SignalrService, private router: Router) {}

  ngOnInit(): void {
    this.signalRService.startConnection();
    this.signalRService.addPostListener();
  }

  ngOnDestroy(): void {
    this.signalRService.stopConnection();
  }

  exibindoNavbar() {
    return this.router.url !== '/login' && this.router.url !== '/register';
  }
}
