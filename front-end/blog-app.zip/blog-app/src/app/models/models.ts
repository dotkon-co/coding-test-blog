export interface PostSumary {
  id: number;
  title: string;
  content: string;
  userId: number;
  imageUrl: string;
}

export interface PostRequest {
  title: string;
  content: string;
  userId: number;
}
