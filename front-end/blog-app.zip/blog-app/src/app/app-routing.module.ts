import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { PostsComponent } from './components/posts/posts.component';
import { PostCreateComponent } from './components/post/post-create/post-create.component';
import { PostUpdateComponent } from './components/post/post-update/post-update.component';
import { PostListComponent } from './components/post/post-list/post-list.component';
import { PostResolveService } from './services/post.resolve';
import { AuthGuard } from './services/auth.guard';
import { RegisterComponent } from './components/register/register.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  { path: 'posts', component: PostListComponent, canActivate: [AuthGuard] },
  {
    path: 'posts/novo',
    component: PostCreateComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'posts/:id',
    component: PostUpdateComponent,
    canActivate: [AuthGuard],
    resolve: { post: PostResolveService },
  },
  { path: 'home', component: PostsComponent },

  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '**', redirectTo: 'home' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
