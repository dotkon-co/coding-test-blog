import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { PostService } from './post.service';
import { PostSumary } from '../models/models';

@Injectable({
  providedIn: 'root',
})
export class PostResolveService {
  constructor(private service: PostService) {}
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): PostSumary | Observable<PostSumary> | Promise<PostSumary> {
    const id = route.params['id'];

    return this.service.getById(id);
  }
}
