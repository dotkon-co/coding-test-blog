import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import * as signalR from '@microsoft/signalr';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SignalrService {
  private hubConnection?: signalR.HubConnection;
  public postUpdate$ = new BehaviorSubject<void>(undefined);

  constructor(private messageService: MessageService) {}

  public startConnection(): void {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${environment.apiUrl}/posthub`, {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    this.hubConnection
      .start()
      .then(() => console.log('Conexão com PostHub iniciada.'))
      .catch((err) => console.error('Erro ao conectar no PostHub:', err));
  }

  public addPostListener(): void {
    this.hubConnection?.on('ReceiveNotification', (postTitle: string) => {
      console.log(`Nova notificação recebida: ${postTitle}`);
      this.postUpdate$.next();
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Novo Post',
      });
    });
  }

  public stopConnection(): void {
    this.hubConnection
      ?.stop()
      .then(() => console.log('Conexão com PostHub encerrada.'))
      .catch((err) => console.error('Erro ao parar conexão:', err));
  }
}
