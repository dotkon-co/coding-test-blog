import { Injectable } from '@angular/core';
import { HttpHelper } from './http-helper';
import { environment } from 'src/environments/environment';
import { PostRequest, PostSumary } from '../models/models';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PostService {
  constructor(private httpHelper: HttpHelper, private http: HttpClient) {}

  getAll() {
    return this.http.get<PostSumary[]>(`${environment.apiUrl}/api/Post`);
  }

  getById(id: number) {
    return this.httpHelper.get<PostSumary>(
      `${environment.apiUrl}/api/Post/${id}`
    );
  }

  delete(id: number) {
    return this.httpHelper.delete<void>(`${environment.apiUrl}/api/Post/${id}`);
  }

  create(post: PostRequest) {
    return this.httpHelper.post<PostSumary>(
      `${environment.apiUrl}/api/Post`,
      post
    );
  }

  update(id: number, post: PostRequest) {
    return this.httpHelper.put<PostSumary>(
      `${environment.apiUrl}/api/Post/${id}`,
      post
    );
  }
}
