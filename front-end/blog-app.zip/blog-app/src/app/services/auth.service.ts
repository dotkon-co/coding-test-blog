import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from './jwt-helper';
import { environment } from 'src/environments/environment';
import { StorageKeys } from '../util/storage-keys';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  jwtPayload: any;
  private url: string;

  constructor(private http: HttpClient, private jwtHelper: JwtHelperService) {
    this.url = `${environment.apiUrl}/api/Auth/login`;
    this.loadToken();
  }

  register(username: string, email: string, password: string) {
    const user = {
      username,
      email,
      password,
    };

    return this.http.post(`${environment.apiUrl}/api/Auth/register`, user);
  }

  login(user: string, password: string) {
    const body = {
      email: user,
      password: password,
    };

    return firstValueFrom(this.http.post<any>(this.url, body))
      .then((response) => {
        this.setAuthState({
          token: response.token,
          isAuthenticated: true,
        });
      })
      .catch((response) => {
        return Promise.reject(response);
      });
  }

  logout() {
    this.clearAccessToken();
  }

  havePermission(...permissions: string[]) {
    const authorities = Array.isArray(this.jwtPayload?.roles)
      ? this.jwtPayload?.roles
      : [this.jwtPayload?.roles];

    return authorities.some((p: string) => permissions.includes(p));
  }

  isAccessTokenInvalid() {
    const token = localStorage.getItem(StorageKeys.AUTH_TOKEN);
    console.log(token);
    return !token || this.jwtHelper.isTokenExpired(token);
  }

  private saveToken(token: string) {
    this.jwtPayload = this.jwtHelper.decodeToken(token);
    localStorage.setItem('token', token);
  }

  private loadToken() {
    const token = localStorage.getItem(StorageKeys.AUTH_TOKEN);

    if (token) {
      this.saveToken(token);
    }
  }

  private clearAccessToken() {
    localStorage.removeItem(StorageKeys.AUTH_TOKEN);
    this.jwtPayload = null;
  }

  private setAuthState(authData: {
    token?: string;
    isAuthenticated: boolean;
  }): void {
    if (authData.isAuthenticated && authData.token) {
      this.jwtPayload = this.jwtHelper.decodeToken(authData.token);
      window.localStorage.setItem(StorageKeys.AUTH_TOKEN, authData.token);
    }
  }
}
