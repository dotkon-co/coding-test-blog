export class StorageKeys {
  static AUTH_TOKEN = 'blog-auth-token';
}
