import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { ErrorHandlerService } from 'src/app/services/error-handler.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
  constructor(
    private auth: AuthService,
    private errorHandler: ErrorHandlerService,
    private router: Router
  ) {}

  register(username: string, email: string, password: string) {
    this.auth.register(username, email, password).subscribe({
      next: () => this.router.navigate(['/login']),
      error: (error) => this.errorHandler.handle(error),
    });
  }
}
