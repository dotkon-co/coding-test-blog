import { Component } from '@angular/core';
import { MessageService } from 'primeng/api';
import { PostRequest } from 'src/app/models/models';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-post-create',
  templateUrl: './post-create.component.html',
  styleUrls: ['./post-create.component.scss'],
})
export class PostCreateComponent {
  constructor(
    private service: PostService,
    private messageService: MessageService
  ) {}

  create(post: PostRequest) {
    this.service.create(post).subscribe({
      next: () =>
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Post criado',
        }),
    });
  }
}
