import { Component, OnDestroy, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { PostSumary } from 'src/app/models/models';
import { AuthService } from 'src/app/services/auth.service';
import { ErrorHandlerService } from 'src/app/services/error-handler.service';
import { PostService } from 'src/app/services/post.service';
import { SignalrService } from 'src/app/services/signalr.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.scss'],
})
export class PostListComponent implements OnInit, OnDestroy {
  posts: PostSumary[] = [];
  private signalRSubscription!: Subscription;

  constructor(
    private confirmation: ConfirmationService,
    private service: PostService,
    private auth: AuthService,
    private errorHandler: ErrorHandlerService,
    private messageService: MessageService,
    private notification: SignalrService
  ) {}

  ngOnInit(): void {
    this.search();
    this.signalRSubscription = this.notification.postUpdate$.subscribe(() => {
      this.search();
    });
  }

  confirmDelete(post: PostSumary) {
    this.confirmation.confirm({
      message: 'Tem certeza que deseja excluir?',
      accept: () => {
        this.delete(post);
      },
    });
  }

  search() {
    this.service.getAll().subscribe({
      next: (respose) => (this.posts = respose),
    });
  }

  haveDeletePermission() {
    return this.auth.havePermission('Admin');
  }

  delete(post: PostSumary) {
    this.service.delete(post.id).subscribe({
      next: () => {
        this.search();
        this.messageService.add({
          severity: 'success',
          summary: 'success',
          detail: 'Post excluido com sucesso',
        });
      },
      error: (error) => this.errorHandler.handle(error),
    });
  }

  ngOnDestroy(): void {
    this.signalRSubscription?.unsubscribe();
  }
}
