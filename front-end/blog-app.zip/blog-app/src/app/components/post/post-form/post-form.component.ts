import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  FormControl,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { PostRequest } from 'src/app/models/models';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-post-form',
  templateUrl: './post-form.component.html',
  styleUrls: ['./post-form.component.scss'],
})
export class PostFormComponent {
  @Input() isEditing = false;

  @Output() eventSubmit = new EventEmitter();

  form = this.createForm();

  constructor(private auth: AuthService, private fb: UntypedFormBuilder) {}

  onSubmit() {
    if (this.form.invalid) return;

    const post = this.form.value;

    if (!this.isEditing) {
      post.userId = this.auth.jwtPayload.userId;
    }

    this.eventSubmit.emit(post);
  }

  getForm(form: string) {
    return this.form.get(form) as FormControl;
  }

  private createForm() {
    return this.fb.group({
      title: [null, [Validators.required]],
      content: [null, [Validators.required]],
      userId: [null],
    });
  }

  @Input()
  set post(value: PostRequest | undefined) {
    if (value) this.form.patchValue(value);
  }
}
