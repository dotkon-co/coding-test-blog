import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PostRequest, PostSumary } from 'src/app/models/models';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-post-update',
  templateUrl: './post-update.component.html',
  styleUrls: ['./post-update.component.scss'],
})
export class PostUpdateComponent implements OnInit {
  post?: PostSumary;

  constructor(
    private route: ActivatedRoute,
    private service: PostService,
    private messageService: MessageService
  ) {}
  ngOnInit(): void {
    this.route.data.subscribe((data) => {
      this.post = data['post'];
    });
  }

  update(post: PostRequest) {
    this.service.update(this.post?.id!, post).subscribe({
      next: () =>
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Post Atualizado',
        }),
    });
  }
}
