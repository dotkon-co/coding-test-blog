import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss'],
})
export class MessageComponent {
  @Input() error?: string;
  @Input() control?: FormControl;
  @Input() text?: string;

  haveError(): boolean {
    return (
      Boolean(this.control) &&
      Boolean(this.control?.hasError(this.error ?? '')) &&
      Boolean(this.control?.dirty)
    );
  }
}
