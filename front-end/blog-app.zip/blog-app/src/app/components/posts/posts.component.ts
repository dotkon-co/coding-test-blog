import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { PostSumary } from 'src/app/models/models';
import { PostService } from 'src/app/services/post.service';
import { SignalrService } from 'src/app/services/signalr.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.scss'],
})
export class PostsComponent implements OnInit, OnDestroy {
  posts: PostSumary[] = [];

  date = new Date();

  private signalRSubscription!: Subscription;

  constructor(
    private service: PostService,
    private notification: SignalrService
  ) {}

  ngOnDestroy(): void {
    this.signalRSubscription?.unsubscribe();
  }

  ngOnInit(): void {
    this.search();
    this.signalRSubscription = this.notification.postUpdate$.subscribe(() => {
      this.search();
    });
  }

  search() {
    this.service.getAll().subscribe({
      next: (respose) => (this.posts = respose),
    });
  }
}
