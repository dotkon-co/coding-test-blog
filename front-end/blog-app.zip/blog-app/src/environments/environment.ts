export const environment = {
  production: false,
  apiUrl: 'http://localhost:5033',
  tokenWhitelistedDomains: [new RegExp('localhost:8081')],
  tokenBlacklistedRoutes: [new RegExp('/oauth/token')],
};
